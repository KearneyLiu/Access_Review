# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Admin',
            fields=[
                ('admin_id', models.EmailField(max_length=60, serialize=False, primary_key=True)),
                ('admin_name', models.CharField(max_length=30)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='App_Manager_Relation',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='App_Permission',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('status', models.CharField(default=b'Read', max_length=30, choices=[(b'Read', 'Read'), (b'Read-Write', 'Read and Write')])),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Application',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('app_name', models.CharField(max_length=30)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Auditor',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('last_name', models.CharField(max_length=30)),
                ('first_name', models.CharField(max_length=30)),
                ('user', models.OneToOneField(to=settings.AUTH_USER_MODEL)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Manager',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('last_name', models.CharField(max_length=30)),
                ('first_name', models.CharField(max_length=30)),
                ('user', models.OneToOneField(to=settings.AUTH_USER_MODEL)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='RegularUser',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('last_name', models.CharField(max_length=30)),
                ('first_name', models.CharField(max_length=30)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.CreateModel(
            name='Test',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('status', models.CharField(max_length=30)),
            ],
            options={
            },
            bases=(models.Model,),
        ),
        migrations.AddField(
            model_name='app_permission',
            name='application',
            field=models.ForeignKey(related_name='application', to='access_review.Application', null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='app_permission',
            name='manager',
            field=models.ForeignKey(related_name='manager', to='access_review.Manager', null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='app_permission',
            name='regular_user',
            field=models.ForeignKey(related_name='regular_user', to='access_review.RegularUser', null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='app_permission',
            name='reviewed_by',
            field=models.ForeignKey(related_name='reviewed_by', to='access_review.Manager', null=True),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='app_manager_relation',
            name='application',
            field=models.ForeignKey(to='access_review.Application'),
            preserve_default=True,
        ),
        migrations.AddField(
            model_name='app_manager_relation',
            name='manager',
            field=models.ForeignKey(to='access_review.Manager', null=True),
            preserve_default=True,
        ),
    ]
