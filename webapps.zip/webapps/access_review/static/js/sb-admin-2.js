$(function() {

    $('#side-menu').metisMenu();

});
