   		$(document).ready(function(){
            $("#id_username").addClass("form-control");
            $("#id_username").attr("required", true);
            $("#id_username").attr("autofocus", true);
            $("#id_username").attr("placeholder", "Username");
            $("#id_password").addClass("form-control");
            $("#id_password").attr("required", true);
            $("#id_password").attr("placeholder", "Password");
        });