from django.db import transaction
from django.http import HttpResponse
from django.shortcuts import render
from access_review.forms import *
from access_review.models import *

from django.shortcuts import render, get_object_or_404
from django.core.exceptions import ObjectDoesNotExist
from django.shortcuts import render, redirect
from django.core.urlresolvers import reverse

# Decorator to use built-in authentication system
from django.contrib.auth.decorators import login_required
from django.contrib.auth.decorators import user_passes_test

# Used to create and manually log in a user
from django.contrib.auth.models import User, Group, Permission
from django.contrib.auth import login, authenticate

# Create your views here.

# Initialized customer group and provider group
manager_users, created = Group.objects.get_or_create(name='Manager')
manager_users.save()

auditor_users, created = Group.objects.get_or_create(name='Auditor')
auditor_users.save()

admin_users, created = Group.objects.get_or_create(name='Admin')
admin_users.save()

# check whether user in customer group
def in_manager(function=None):
  actual_decorator = user_passes_test(
    lambda u: u.is_authenticated() and u.groups.filter(name='Manager').exists()
  )
  return actual_decorator(function)

# check whether user in provider group
def in_auditor(function=None):
  actual_decorator = user_passes_test(
    lambda u: u.is_authenticated() and u.groups.filter(name='Auditor').exists()
  )
  return actual_decorator(function)

def in_admin(function=None):
  actual_decorator = user_passes_test(
    lambda u: u.is_authenticated() and u.groups.filter(name='Admin').exists()
  )
  return actual_decorator(function)

def welcome(request):
    # Sets up list of just the logged-in user's (request.user's) items
    print 'WELCOME'
    return render(request, 'welcome.html', {})

@login_required
def filter(request):
    usr = User.objects.get_by_natural_key(request.user)
    try:
        customer = Manager.objects.get(user=usr)
        return redirect(reverse('home'))
    except(Manager.DoesNotExist):
        pass
    try:
        provider = Auditor.objects.get(user=usr)
        return redirect(reverse('audit'))
    except(Auditor.DoesNotExist):
        pass

    try:
        admin = Admin.objects.get(user=usr)
        return redirect(reverse('admin'))
    except(Admin.DoesNotExist):
        raise 404


def my_login(request):
    context = {}
    if request.method == 'GET':
        context['form'] = LoginForm()
        return render(request, 'login.html', context)

    form = LoginForm(request.POST)
    context['form'] = form
    if not form.is_valid():
        print '????'
        return render(request, 'login.html', context)

    try:
        user = authenticate(username=form.cleaned_data['username'],
                            password=form.cleaned_data['password'])
        if user == None:
            context = { 'form': form,
                'message':'The username or password is wrong. Please try again.'}
            return render(request, 'login.html', context)
        login(request, user)
        #need to be updated
    except(AttributeError):
        return redirect(reverse('login'))

    return filter(request)


@transaction.atomic
def manager_register(request):
    context = {}

    # Just display the registration form if this is a GET request
    if request.method == 'GET':
        context['form'] = ManagerRegistrationForm()
        return render(request, 'register.html', context)

    errors = []
    context['errors'] = errors

    form = ManagerRegistrationForm(request.POST)
    context['form'] = form
    if not form.is_valid():
        return render(request, 'register.html', context)

    # Creates the new user from the valid form data
    new_user = User.objects.create_user(username=form.cleaned_data['username'], \
                                        password=form.cleaned_data['password1'], \
                                        first_name=form.cleaned_data['first_name'], \
                                        last_name=form.cleaned_data['last_name'], \
                                        email=form.cleaned_data['email'])
    if form.is_valid():

        new_manager, created = Manager.objects.get_or_create(user = new_user,
                                                               first_name=form.cleaned_data['first_name'],
                                                               last_name=form.cleaned_data['last_name'],)
        new_manager.save()

    new_user = authenticate(username=form.cleaned_data['username'],
                            password=form.cleaned_data['password1'])
    new_user.groups.add(manager_users)
    login(request, new_user)
    return redirect(reverse('home'))

@transaction.atomic
def auditor_register(request):
    context = {}

    # Just display the registration form if this is a GET request
    if request.method == 'GET':
        context['form'] = AuditorRegistrationForm()
        return render(request, 'auditor_register.html', context)

    errors = []
    context['errors'] = errors

    form = AuditorRegistrationForm(request.POST)
    context['form'] = form

    if not form.is_valid():
        print '????++'
        print form.errors
        print form
        return render(request, 'auditor_register.html', context)

    # Creates the new user from the valid form data
    new_user = User.objects.create_user(username=form.cleaned_data['username'], \
                                        password=form.cleaned_data['password1'], \
                                        first_name=form.cleaned_data['first_name'], \
                                        last_name=form.cleaned_data['last_name'], \
                                        email=form.cleaned_data['email'])
    if form.is_valid():
        new_auditor, created = Auditor.objects.get_or_create(user = new_user,
                                                               first_name=form.cleaned_data['first_name'],
                                                                last_name=form.cleaned_data['last_name'],)
        new_auditor.save()



    new_user = authenticate(username=form.cleaned_data['username'],
                            password=form.cleaned_data['password1'])

    new_user.groups.add(auditor_users)

    login(request, new_user)
    return redirect(reverse('audit'))

@transaction.atomic
def admin_register(request):
    context = {}

    # Just display the registration form if this is a GET request
    if request.method == 'GET':
        context['form'] = AdminRegistrationForm()
        return render(request, 'admin_register.html', context)

    errors = []
    context['errors'] = errors

    form = AdminRegistrationForm(request.POST)
    context['form'] = form
    if not form.is_valid():
        return render(request, 'admin_register.html', context)

    # Creates the new user from the valid form data
    new_user = User.objects.create_user(username=form.cleaned_data['username'], \
                                        password=form.cleaned_data['password1'], \
                                        first_name=form.cleaned_data['first_name'], \
                                        last_name=form.cleaned_data['last_name'], \
                                        email=form.cleaned_data['email'])
    if form.is_valid():

        new_admin, created = Admin.objects.get_or_create(user = new_user,
                                                               first_name=form.cleaned_data['first_name'],
                                                               last_name=form.cleaned_data['last_name'],)
        new_admin.save()

    new_user = authenticate(username=form.cleaned_data['username'],
                            password=form.cleaned_data['password1'])
    new_user.groups.add(admin_users)
    login(request, new_user)
    return redirect(reverse('admin'))

@in_manager
def home(request):
    context = {}
    print("manager")
    #toplists = Provider.objects.all().order_by('-count')[:10]
    #markers = Marker.objects.all()
    #context = {
    #    'toplists': toplists,
    #    'markers': markers
    #}
    manager = get_object_or_404(Manager, user = request.user)
    relations = App_Manager_Relation.objects.filter(manager=manager)
    applications = []
    for relation in relations:
        applications.append(relation.application)

    permissions = App_Permission.objects.filter(application = applications[0])

    context = {'permissions':permissions, 'applications': applications}
    return render(request, 'homepage.html', context)

@in_manager
def view_permission(request, id):
    application = get_object_or_404(Application, id=id)
    permissions = App_Permission.objects.filter(application = application)

    manager = get_object_or_404(Manager, user = request.user)
    relations = App_Manager_Relation.objects.filter(manager=manager)
    applications = []
    for relation in relations:
        applications.append(relation.application)


    context = {'permissions':permissions, 'applications': applications}
    return render(request, "view_permission.html", context)



@transaction.atomic
def addData(request):
    print("add data")
    manager = get_object_or_404(Manager, user = request.user)
    application = Application.objects.create(app_name = "AWS")
    print application
    application2 = Application.objects.create(app_name = "Google")
    application.save()
    application2.save()


    app_manager_relation = App_Manager_Relation.objects.create(application = application, manager = manager)
    app_manager_relation.save()
    app_manager_relation2 = App_Manager_Relation.objects.create(application = application2, manager = manager)
    app_manager_relation2.save()
    #print application
    #print app_manager_relation

    ruser1 = RegularUser.objects.create(last_name="Josh", first_name='Smith')
    ruser2 = RegularUser.objects.create(last_name="Kobe", first_name='Paul')
    ruser3 = RegularUser.objects.create(last_name="Taylor", first_name='Fisher')

    ruser1.save()
    ruser2.save()
    ruser3.save()

    permission1, created = App_Permission.objects.get_or_create(application = application, regular_user=ruser1, manager=manager,
                                                       status="Read", reviewed_by=manager)
    permission2, created = App_Permission.objects.get_or_create(application = application, regular_user=ruser2, manager=manager,
                                                       status="Read-Write", reviewed_by=manager)
    permission3, created = App_Permission.objects.get_or_create(application = application, regular_user=ruser3, manager=manager,
                                                       status="Read-Write", reviewed_by=manager)
    permission4, created = App_Permission.objects.get_or_create(application = application2, regular_user=ruser1, manager=manager,
                                                       status="Read", reviewed_by=manager)
    permission5, created = App_Permission.objects.get_or_create(application = application2, regular_user=ruser2, manager=manager,
                                                       status="Read-Write", reviewed_by=manager)
    permission6, created = App_Permission.objects.get_or_create(application = application2, regular_user=ruser3, manager=manager,
                                                       status="Read-Write", reviewed_by=manager)

    permission1.save()
    permission2.save()
    permission3.save()
    permission4.save()
    permission5.save()
    permission6.save()

    return HttpResponse("all done")


@transaction.atomic
def addData_2(request):
    print("add data")
    manager = get_object_or_404(Manager, user = request.user)
    application = Application.objects.get(app_name = "AWS")
    print application
    application2 = Application.objects.get(app_name = "Google")
    print application2

    #app_manager_relation = App_Manager_Relation.objects.create(application = application, manager = manager)
    #app_manager_relation.save()
    #app_manager_relation2 = App_Manager_Relation.objects.create(application = application2, manager = manager)
    #app_manager_relation2.save()
    #print application
    #print app_manager_relation

    ruser1 = RegularUser.objects.get(last_name="Josh", first_name='Smith')
    ruser2 = RegularUser.objects.get(last_name="Kobe", first_name='Paul')
    ruser3 = RegularUser.objects.get(last_name="Taylor", first_name='Fisher')


    permission3, created = App_Permission.objects.get_or_create(application = application, regular_user=ruser3, manager=manager,
                                                       status="Read-Write", reviewed_by=manager)
    permission4, created = App_Permission.objects.get_or_create(application = application2, regular_user=ruser1, manager=manager,
                                                       status="Read", reviewed_by=manager)
    permission5, created = App_Permission.objects.get_or_create(application = application2, regular_user=ruser2, manager=manager,
                                                       status="Read-Write", reviewed_by=manager)
    permission6, created = App_Permission.objects.get_or_create(application = application2, regular_user=ruser3, manager=manager,
                                                       status="Read-Write", reviewed_by=manager)


    permission3.save()
    permission4.save()
    permission5.save()
    permission6.save()

    return HttpResponse("all done")


@in_manager
def edit_permission(request, id):
    permission = get_object_or_404(App_Permission, id=id)
    print permission
    if request.method == 'GET':
        form = PermissionForm(instance=permission)
        context = { 'permission':permission, 'form': form }
        return render(request, 'edit_permission.html', context)

    form = PermissionForm(request.POST, instance=permission)

    if not form.is_valid():
        context = { 'message':'status wrong', 'permission': permission, 'form': form  }

        return render(request, 'edit_permission.html', context)

    form.save()
    permission.reviewed_by = get_object_or_404(Manager, user = request.user)
    permission.save()


    application = permission.application
    return redirect(reverse('view_permission', args=(application.id,)))



@in_auditor
def audit(request):
    context = {}
    print("audit")

    return render(request, 'homepage.html', context)

@in_admin
def admin(request):
    print("admin")

    admin = get_object_or_404(Admin, user = request.user)
    managers = Manager.objects.all()
    auditos = Auditor.objects.all()
    applications = Application.objects.all()
    manager_relations = App_Manager_Relation.objects.filter(application=applications[0])
    auditor_relations = App_Auditor_Relation.objects.filter(application=applications[0])

    approved_managers = []
    approved_auditors = []

    applications = []
    for m_relation in manager_relations:
        approved_managers.append(m_relation.manager)
    for a_relation in auditor_relations:
        approved_auditors.append(a_relation.auditor)

    wait_managers = Manager.objects.exclude(manager__in=approved_managers)
    wait_auditors = Auditor.objects.exclude(auditor__in=approved_auditors)

    context = {'applications': applications, 'approved_managers':approved_managers, 'approved_auditors':approved_auditors,
               'wait_managers':wait_managers, 'wait_auditors':wait_auditors}

    return render(request, 'admin_home.html', context)



@in_admin
def view_assignment(request, id):

    admin = get_object_or_404(Admin, user = request.user)
    managers = Manager.objects.all()
    auditos = Auditor.objects.all()

    application = get_object_or_404(Application, id=id)

    manager_relations = App_Manager_Relation.objects.filter(application=application)
    auditor_relations = App_Auditor_Relation.objects.filter(application=application)

    approved_managers = []
    approved_auditors = []

    applications = []
    for m_relation in manager_relations:
        approved_managers.append(m_relation.manager)
    for a_relation in auditor_relations:
        approved_auditors.append(a_relation.auditor)

    wait_managers = Manager.objects.exclude(manager__in=approved_managers)
    wait_auditors = Auditor.objects.exclude(auditor__in=approved_auditors)

    context = {'applications': applications, 'approved_managers':approved_managers, 'approved_auditors':approved_auditors,
               'wait_managers':wait_managers, 'wait_auditors':wait_auditors}

    return render(request, 'view_assignment.html', context)

def assign_assignment(request, id):

    #return redirect(reverse('view_permission', args=(application.id,)))

    return "1"

def remove_assignment(request, id):

    return "2"